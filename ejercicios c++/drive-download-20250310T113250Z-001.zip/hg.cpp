#include <iostream>
using namespace std;
string n="";
cout<<"ingresa"<<endl;
cin>>n>>endl;
int main(){
    if(n=="medallo faso rico huele"){
        n="ta suavesita she likes hombres y mujeres";
    }
}