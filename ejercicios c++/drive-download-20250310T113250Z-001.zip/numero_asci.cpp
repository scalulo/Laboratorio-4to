#include <iostream>
using namespace std;

int main(){
    char c='a';
    int code_caracter=c;
    

    cout<<"el numero ascii es: "<<code_caracter<<endl;
}