#include <iostream>
using namespace std;

int main(){
    float nh;
    float nm;
    cout<<"ingrese numero de hombres"<<endl;
    cin>>nh;
    cout<<"ingrese numero de mujeres"<<endl;
    cin>>nm;
    int s=nh+nm;
    float ph=100*(nh/s);
    float pm=100*(nm/s);
    cout<<"porcentaje de hombres: "<<ph<<endl;
    cout<<"porcentaje de mujeres: "<<pm<<endl;
}