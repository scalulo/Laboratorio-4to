#include <iostream>
using namespace std;

int main(){
    char r;
    int code_caracter=r;
    cout<<"ingrese caracter: "<<endl;
    cin>>r;
    if(r<=90){
        cout<<"Mayuscula"<<endl;
    }
    else{
    cout<<"Miniscula"<<endl;
    }
}