#include <iostream>
using namespace std;

int main(){
    float n1;
    float n2;
    cout<<"ingrese el primer numero"<<endl;
    cin>>n1;
    cout<<"ingrese segundo numero"<<endl;
    cin>>n2;
    
while(n1!=n2){
    if(n1<=n2){
    cout<<n1<<endl;
    n1=n1+1;
    }
}
cout<<n2<<endl;
}
