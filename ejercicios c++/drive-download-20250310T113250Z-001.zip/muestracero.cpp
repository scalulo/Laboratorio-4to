#include <iostream>
using namespace std;

int main(){
    int n1=1;
   
   int n3=0;
     while(n1!=0){
    cout<<"ingrese el primer numero"<<endl;
    cin>>n1;
    n3=n1+n3;
    }
   
    cout<<n3;
}