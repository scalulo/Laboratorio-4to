#include <iostream>
using namespace std;

int main(){
    float n=1;
    
    

    
    while(n!=0){
    cout<<"ingrese numero"<<endl;
    cin>>n;
    if(n==0){
        cout<<"programa frenado"<<endl;
    }
    else{
        cout<<n*2<<endl;
    }
    }
}

