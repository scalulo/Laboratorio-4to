#include <iostream>
using namespace std;

int main(){
float n;
float n1;
 cout << "ingresar numero 1: " << endl;
  cin >> n;
  cout << "ingresar numero 2: " << endl;
  cin >> n1;
  if(n<n1){
    cout << "el numero 1 es menor que el 2" << endl;
  }
  if(n>n1){
    cout << "el numero 1 es mayor que el 2" << endl;
  }
  else if (n==n1){
    cout << "el numero 1 es igual que el 2" << endl;
  }
}