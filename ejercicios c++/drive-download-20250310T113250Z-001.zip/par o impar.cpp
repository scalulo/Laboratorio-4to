#include <iostream>
using namespace std;

int main(){
    int n;
    cout<<"ingrese numero"<<endl;
    cin>>n;
    if(n%2==0){
        cout<<"es par"<<endl;
        
}
else{
    cout<<"es impar"<<endl;
}
}
    
        
    