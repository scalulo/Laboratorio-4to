#include <iostream>
using namespace std;

int main(){
    int nl,pr;
    cout<<"ingrese la cantidad de libros que desea"<<endl;
    cin>>nl;
    if(nl>=5){
   pr=250;
    }
    else{
   pr=300;
    }
    int mon=nl*pr;
    cout<<"el monto totales: ";
    cout<<mon<<endl;
}