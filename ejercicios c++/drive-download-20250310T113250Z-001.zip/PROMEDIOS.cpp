#include <iostream>
using namespace std;

int main(){
  float n1;
  float n2;
  cout << "ingresar numero 1: " << endl;
  cin >> n1;
  cout << "ingresar numero 2: " << endl;
  cin >> n2;
  float promedio = (n1+n2)/2;
  cout<<promedio<<endl;
}
