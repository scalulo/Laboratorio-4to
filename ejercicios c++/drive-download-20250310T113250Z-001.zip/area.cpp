#include <iostream>
using namespace std;

int main(){
    float base;
  float altura;
  cout<<"ingrese altura"<<endl;
  cin>>altura;
  cout<<"ingrese base"<<endl;
  cin>>base;
  float area = (base*altura)/2;
  cout<<area<<endl;
}
