#include <iostream>
using namespace std;

int main(){
    int n1;
    int n=23074827159;
    while(n1!=n){
     cout<<"ingrese el numero"<<endl;
    cin>>n1;
   if(n1<0){
    n1=n1*(-1);
   }
   if(n1%2==0){
    cout<<"el numero es par"<<endl;

   }
   else{
    cout<<"el numero es impar"<<endl;
   }
    }
}
