#include <iostream>
using namespace std;

int main(){
    int n;
    
     cout<<"ingrese un numero: "<<endl;
    cin>>n;
    bool ope=(n>0);
    bool ope1=(n<10);
    bool ope2=(n!=5);
    if(ope and ope1 and ope2){
    cout<<"se cumple la condicion "<<endl;
    }
  
  else{
    cout<<"no se cumple la condicion  "<<endl;
  }
}

