#include <iostream>
using namespace std;

int main(){
    float n;
    
     cout<<"ingrese un numero: "<<endl;
    cin>>n;
    bool ope=(n>0);
    bool ope1=(n<10);
    if(ope and ope1){
    cout<<"se cumple la condicion "<<endl;
    }
  
  else{
    cout<<"no se cumple la condicion  "<<endl;
  }
}

