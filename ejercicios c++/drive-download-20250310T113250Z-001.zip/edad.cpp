#include <iostream>
using namespace std;

int main(){
    float nh;
    float nm;
    cout<<"ingrese numero de hombres"<<endl;
    cin>>nh;
    cout<<"ingrese numero de mujeres"<<endl;
    cin>>nm;

}