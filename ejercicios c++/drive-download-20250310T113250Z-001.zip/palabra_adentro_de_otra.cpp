#include <iostream>
using namespace std;


int main() {
    string p1;
    string p2;
    int cantLetras1;
    int cantLetras2;
    cout << "Ingrese la primera palabra: "<<endl;
    cin>>p1;
    cout << "Ingrese la segunda palabra: "<<endl;
    cin >> p2;
    cantLetras1 = size(p1);
    cantLetras2 = size(p2);
    if (cantLetras1 > cantLetras2)
    {
        while (cantLetras1 != 0)
    {
        if (p1[cantLetras1-1] == p2[cantLetras2-1]){
            cantLetras1--;
            if (p1[cantLetras1-1] == p2[cantLetras2-2]){
                cantLetras1--;
                if (p1[cantLetras1-1] == p2[cantLetras2-3]){
                    cout << p2 <<" está dentro de "<< p1 << endl;
                    break;
                }
            }
        }
        else{
          cantLetras1--;
        }   
    }
}else{
    while (cantLetras2 != 0)
    {
        if (p2[cantLetras2-1] == p1[cantLetras1-1]){
            cantLetras2--;
            if (p2[cantLetras2-1] == p1[cantLetras1-2]){
                cantLetras2--;
                if (p2[cantLetras2-1] == p1[cantLetras1-3]){
                    cout << p1 <<" está dentro de "<< p2 << endl;
                    break;
                }
            }
        }
        else{
          cantLetras2--;
        }   
    }
    }
}