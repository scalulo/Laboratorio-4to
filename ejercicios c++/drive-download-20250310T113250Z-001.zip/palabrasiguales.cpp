#include <iostream>
using namespace std;

int main(){
    string cadena1;
    string cadena2;
    cout<<"ingrese primera palabra: "<<endl;
    cin>>cadena1;
    cout<<"ingrese segunda palabra: "<<endl;
    cin>>cadena2;
    if(cadena1==cadena2){
        cout<<"son iguales"<<endl;
    }
    else {
        cout<<"son diferentes"<<endl;
    }
}