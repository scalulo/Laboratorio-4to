#include <iostream>
using namespace std;

int main(){
    float n1;
    float n2;
     cout << "ingresar numero 1: " << endl;
  cin >> n1;
  cout << "ingresar numero 2: " << endl;
  cin >> n2;
  
   int suma=n1+n2;
   cout<<"suma: "<<suma<<endl;
   
   int resta=n1-n2;
   cout<<"resta: "<<resta<<endl;
  
   int multi=n1*n2;
   cout<<"multiplicacion: "<<multi<<endl;
  
   if(n2==0){
    cout<<"no se puede dividir por 0"<<endl;
   
}
else{
    float div=n1/n2;
   cout<<"division: "<<div<<endl;
}
}